import {SEARCH_USER, GO_BACK_TO_SEARCH} from './types';

export handleSearchUser = () => ({type: SEARCH_USER})
export handleBackToSearch = () => ({type: GO_BACK_TO_SEARCH})
